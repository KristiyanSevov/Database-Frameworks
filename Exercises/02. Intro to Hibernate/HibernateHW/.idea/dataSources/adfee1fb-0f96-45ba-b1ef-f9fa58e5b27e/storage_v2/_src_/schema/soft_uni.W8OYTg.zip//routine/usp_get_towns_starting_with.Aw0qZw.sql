CREATE PROCEDURE usp_get_towns_starting_with(IN str VARCHAR(50))
  BEGIN
	SELECT name as town_name FROM towns 
	WHERE LEFT(name, CHAR_LENGTH(str)) = str
	ORDER BY name;
END;

