CREATE TRIGGER log_deleted_employees
  AFTER DELETE
  ON employees
  FOR EACH ROW
  BEGIN
INSERT INTO deleted_employees
VALUES (OLD.employee_id, OLD.first_name, OLD.last_name, OLD.middle_name,
OLD.job_title, OLD.department_id, OLD.salary);
END;

