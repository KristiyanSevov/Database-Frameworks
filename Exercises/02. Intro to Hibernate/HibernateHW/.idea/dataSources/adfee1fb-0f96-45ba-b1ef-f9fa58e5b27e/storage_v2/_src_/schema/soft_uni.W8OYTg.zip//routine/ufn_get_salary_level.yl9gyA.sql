CREATE FUNCTION ufn_get_salary_level(salary DOUBLE)
  RETURNS VARCHAR(50)
  BEGIN
	DECLARE result VARCHAR(50);
	SET result = (CASE WHEN salary < 30000 THEN 'Low'
		 WHEN salary BETWEEN 30000 AND 50000 THEN 'Average'
		 ELSE 'High' END);
	RETURN result;
END;

