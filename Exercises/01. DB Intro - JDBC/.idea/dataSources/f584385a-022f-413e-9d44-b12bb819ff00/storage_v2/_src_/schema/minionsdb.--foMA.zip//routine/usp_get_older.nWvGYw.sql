CREATE PROCEDURE usp_get_older(IN minion_id INT)
  BEGIN
	UPDATE minions
	SET age = age + 1
	WHERE minion_id = id;
END;

